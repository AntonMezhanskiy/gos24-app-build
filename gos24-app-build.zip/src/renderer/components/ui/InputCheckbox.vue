<template>
  <div class="InputCheckbox">
    InputCheckbox
  </div>
</template>

<script>
export default {
  name: 'InputCheckbox'
};
</script>

<style scoped></style>
